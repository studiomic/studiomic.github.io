const Studioheader = () => {
	return(
			<header>
				<h1>すたじおみっく。</h1>
				<p><a href="https://www.studiomic.net/">www.studiomic.net</a></p>
			</header>
	);
}

export default Studioheader;