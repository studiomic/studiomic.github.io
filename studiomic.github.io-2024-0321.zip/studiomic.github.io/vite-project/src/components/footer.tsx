const Footer = () => {
	return(
			<footer>
					<h1>Footer Title</h1>
					<p>Footer paragraph</p>
			</footer>
	);
}

export default Footer;