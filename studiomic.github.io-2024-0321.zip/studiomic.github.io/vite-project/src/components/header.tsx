const Header = () => {
	return(
			<header>
					<h1>Header Title</h1>
					<p>Header paragraph</p>
			</header>
	);
}

export default Header;