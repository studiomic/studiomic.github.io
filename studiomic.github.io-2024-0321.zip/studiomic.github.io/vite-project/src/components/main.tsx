const MainContent = () => {
	return(
			<main>
					<h1>MainContent Title</h1>
					<p>MainContent paragraph</p>
			</main>
	);
}

export default MainContent;